﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HBMS.Entity;
using HBMS.Exception;
using System.Data.Entity.Validation;

namespace HBMS.DAL
{
    public class HBMSOperations
    {
        static HotelEntities context = new HotelEntities();

        #region Customer and Hotel-Employee Operations
        //Insert data into Users Table
        public static int RegisterUser(User u)
        {
            int records = 0;

            try 
            {
                 context.Users.Add(u);
                 records = context.SaveChanges();
            }

            catch(SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Register User and Returning UserID
        public static string RegisterUserReturningId(User u)
        {
            string id;

            try
            {
                context.Users.Add(u);
                context.SaveChanges();
                id = (from t in context.Users
                      where t.UserName == u.UserName && t.Password == u.Password
                      select t.UserID).FirstOrDefault();

            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return id;
        }



        //Check login for admin  merge it with CheckLogin function in admin
        public static int CheckLogin(string userid,string pwd)
        {
            int status = 0;

            var obj = (from u in context.Users
                       where u.UserID == userid && u.Password == pwd
                       select u).FirstOrDefault();

            if (obj != null && obj.Role.ToLower() == "admin")
                status = 1;
            else if (obj != null)
                status = -1;

            return status;
        }


        //Book hotel room
        public static  int  BookRoom(BookingDetail bd)
        {
            int records = 0;

            try
            {
                context.BookingDetails.Add(bd);
                records=context.SaveChanges();
            }
                catch (DbEntityValidationException ex)
        {
            // Retrieve the error messages as a list of strings.
            var errorMessages = ex.EntityValidationErrors
                    .SelectMany(x => x.ValidationErrors)
                    .Select(x => x.ErrorMessage);
 
            // Join the list to a single string.
            var fullErrorMessage = errorMessages;
 
            // Combine the original exception message with the new one.
            var exceptionMessage = string.Concat(ex.Message, "The validation errors are:", fullErrorMessage);
 
            // Throw a new DbEntityValidationException with the improved exception message.
            throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
        }

            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Search Hotel according to location
        public static List<Hotel> SearchHotel(string loc)
        {
            List<Hotel> hotelList = null;
            
            try 
            {
                hotelList = (from h in context.Hotels
                             where h.City == loc
                             select h).ToList<Hotel>();
            }

            catch(SystemException ex)
            {
                throw ex;
            }

            return hotelList;
        }
        #endregion


        #region Admin operations

        //•	Performing Hotel Management (add/delete/modify Hotel info like description, any special offers etc)

        //Add Hotel
        public static int AddHotel(Hotel h)
        {
            int records = 0;

            try
            {
                context.Hotels.Add(h);
                records = context.SaveChanges();
            }

            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Delete Hotel
        public static int DeleteHotel(string hotelid)
        {
            int records = 0;

            try
            {
                var hotel = (from r in context.Hotels
                            where r.HotelID==hotelid
                            select r).FirstOrDefault();

                if (hotel != null)
                {
                    context.Hotels.Remove(hotel);
                    records = context.SaveChanges();
                }
                else
                    throw new HBMSException("Hotel not found for deletion");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Modify Hotel Details
        public static int ModifyHotel(string description,string hid)
        {
            int records = 0;

            try
            {
                var hotel = (from r in context.Hotels
                            where r.HotelID == hid
                            select r).FirstOrDefault();

                if (hotel != null)
                {
                    hotel.Description = description;

                    records = context.SaveChanges();
                }
                else
                    throw new HBMSException("Hotel not found for updation");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        


        //•	Performing Room Management (add/delete/modify Rooms, modify room tariff) 
        //Add Room
        public static int AddRoom(RoomDetail rd)
        {
            int records = 0;
            
            try
            {
                context.RoomDetails.Add(rd);
                records = context.SaveChanges();
            }

            catch(SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Delete Rooms
        public static int DeleteRoom(string hotelid,int roomid)
        {
            int records = 0;

            try
            {
                var room = (from r in context.RoomDetails
                                where r.RoomID == roomid && r.HotelID==hotelid
                                select r).FirstOrDefault();

                if (room != null)
                {
                    context.RoomDetails.Remove(room);
                    records = context.SaveChanges();
                }
                else
                    throw new HBMSException("Room not found for deletion");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }


        //Modify Room Details
        public static int ModifyRoom(RoomDetail rd)
        {
            int records = 0;

            try
            {
                var room = (from r in context.RoomDetails
                                where r.HotelID==rd.HotelID && r.RoomID==rd.RoomID
                                select r).FirstOrDefault();

                if (room != null)
                {
                    room.PerNightRate = rd.PerNightRate;

                    records = context.SaveChanges();
                }
                else
                    throw new HBMSException("Room not found for updation");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //To get list of rooms
        public static List<RoomDetail> GetRoomList()
        {

            List<RoomDetail> roomList = null;

            try
            {
                roomList = (from t1 in context.RoomDetails
                            select t1).ToList<RoomDetail>();
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return roomList;
        }


        //•	Generating various reports 
        //Get List of Hotels
        public static List<Hotel> GetHotelList()
        {
            List<Hotel> hotelList = null;

            try
            {
                hotelList = context.Hotels.ToList<Hotel>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return hotelList;
        }


        //Bookings of Specific Hotels
        public static List<BookingDetail> GetBookingDetails(string hotelid)
        {
            List<BookingDetail> bdList = null;

            try 
            {
                bdList = (from t1 in context.BookingDetails
                          join t2 in context.RoomDetails on t1.RoomID equals t2.RoomID
                          join t3 in context.Hotels on t2.HotelID equals t3.HotelID
                          where t3.HotelID == hotelid
                          select t1).ToList<BookingDetail>();

                        
            }


            catch(SystemException ex)
            {
                throw ex;
            }

            return bdList;
        }

        //Guest List of Specific Hotels
        public static List<User> GetGuests(string hotelid)
        {
            Array a;
            List<User> guestList = null;

            try
            {
                a = (from t1 in context.BookingDetails
                     join t2 in context.RoomDetails on t1.RoomID equals t2.RoomID
                     where t2.HotelID == hotelid
                     select t1.UserID).ToArray();

                foreach (var item in a)
                {
                    guestList = (from t1 in context.Users
                                 where t1.UserID == item.ToString()
                                 select t1).ToList<User>();
                }
                
               
             }


            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }



        //Bookings for Specified Date
        public static List<BookingDetail> GetBookingsForADate(DateTime date)
        {

            List<BookingDetail> bdList = null;

            try
            {
                 bdList = (from t1 in context.BookingDetails
                             where t1.BookedFrom == date
                             select t1).ToList<BookingDetail>();
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return bdList;
        }

        #endregion


        #region Booking Page

        //Check Availability of rooms in given hotel
        public static bool CheckAvailablility(string hotelid = "1002")
        {
            bool records = false;

            try
            {
                var hotel = (from r in context.RoomDetails
                             where r.HotelID == hotelid && r.Availability
                             select r).FirstOrDefault();

                if (hotel != null)
                {
                    records = true;
                }
                else
                    throw new HBMSException("Rooms are not available");
            }
            catch (HBMSException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }
        #endregion

        //To get list of locations
        public static List<string> GetHotelLocations()
        {

            List<string> locList = null;

            try
            {
                locList = (from t1 in context.Hotels
                           select t1.City).Distinct<string>().ToList<string>();
            }


            catch (SystemException ex)
            {
                throw ex;
            }

            return locList;
        }
    }
}
