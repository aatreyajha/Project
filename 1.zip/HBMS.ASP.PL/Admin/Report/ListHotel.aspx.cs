﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.BL;
using HBMS.Exception;

namespace HBMS.ASP.PL.Admin.Report
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            grid_ListHotel.DataSource = HBMSValidations.GetHotelList();
            grid_ListHotel.DataBind();
        }
    }
}