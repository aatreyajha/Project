﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.BL;
using HBMS.Exception;

namespace HBMS.ASP.PL.Admin.Report
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnHotelGuest_Click(object sender, EventArgs e)
        {
            try
            {
                List<BookingDetail> liq = HBMSValidations.GetBookingDetails(txtID.Text);
                if (liq != null)
                {
                    GridView1.DataSource = liq;
                    GridView1.DataBind();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('No booking found in hotel...')", true);

                }
            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
        }
    }
}