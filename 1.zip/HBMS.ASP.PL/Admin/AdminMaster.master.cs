﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBMS.ASP.PL.Admin
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (Session["loginstatus"].ToString() != "User" )
                {
                    Response.Redirect("~/Account/Login.aspx");
                }

                HBMSMaster myMasterPage = (HBMSMaster)Page.Master.Master.Master;

                ControlCollection li = myMasterPage.Controls;

                LinkButton re = (LinkButton)myMasterPage.FindControl("linkbtn_Register");
                re.Enabled = false;
                re.Visible = false;

                LinkButton lo = (LinkButton)myMasterPage.FindControl("linkbtn_Login");
                lo.Text = "Log Out";
                lo.PostBackUrl = @"~/Default.aspx";
            }

            catch(SystemException ex)
            {

            }
            
          
        }
    }
}