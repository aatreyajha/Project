﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Admin.Operation.Room
{
    public partial class ModifyRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                txtHotelId.Text = Session["HotelId"].ToString();
                txtRoomId.Text = Session["RoomId"].ToString();
            }

            catch (SystemException)
            { }
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                RoomDetail rd = new RoomDetail();
                rd.RoomID = Convert.ToInt32(txtRoomId.Text);
                rd.HotelID = txtHotelId.Text;
                rd.PerNightRate = Convert.ToInt32(txtModFare.Text);

                int records = HBMSValidations.ModifyRoom(rd);

                if (records > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Room Fare Modified Successfully')", true);

                }
                else
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Room Fare not modified')", true);

            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
            }
        }
    }
}