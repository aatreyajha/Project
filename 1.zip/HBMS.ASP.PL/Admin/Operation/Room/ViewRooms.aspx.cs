﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Admin.Operation.Room
{
    public partial class ViewRooms : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            grid_ListRoom.DataSource = HBMSValidations.GetRoomList();
            grid_ListRoom.DataBind();
        }

        protected void grid_ListRoom_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string[] arg = new string[2];
            arg = e.CommandArgument.ToString().Split(';');
            Session["HotelId"] = arg[0];
            Session["RoomId"] = arg[1];
            
            if(e.CommandName=="Modify")
            {
               
                Response.Redirect("ModifyRoom.aspx");
            }

            else if(e.CommandName=="Delete")
            {
                Response.Redirect("DeleteRoom.aspx");
            }
        }

        

       
    }
}