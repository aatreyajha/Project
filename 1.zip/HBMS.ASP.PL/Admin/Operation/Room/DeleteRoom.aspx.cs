﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Admin.Operation.Room
{
    public partial class DeleteRoom : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                txtHotelId.Text = Session["HotelId"].ToString();
                txtRoomId.Text = Session["RoomId"].ToString();
            }

            catch (SystemException)
            { }
        }

     

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int count = HBMSValidations.DeleteRoom(txtHotelId.Text, Convert.ToInt32(txtRoomId.Text));

                if (count > 0)
                {

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Room Deleted Successfully')", true);

                }

                else
                    throw new HBMSException("Room not Deleted");
            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert(" + ex.Message + ")", true);
            }
        }
    }
}