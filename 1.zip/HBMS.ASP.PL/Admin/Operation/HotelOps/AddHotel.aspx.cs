﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.BL;
using HBMS.Entity;
using HBMS.Exception;

namespace HBMS.ASP.PL.Admin.Operation.HotelOps
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnAddHotel_Click(object sender, EventArgs e)
        {
            try
            {
                Hotel h = new Hotel();
                h.HotelID = txtID.Text.Trim();
                h.HotelName = txtName.Text.Trim();
                h.City = txtCity.Text.Trim();
                h.Address = txtAddress.Text.Trim();
                h.Description = txtDescription.Text.Trim();
                h.PhoneNo1 = txtMobile.Text;
                h.PhoneNo2 = txtPhone.Text;
                h.Rating = txtRating.Text;
                h.Email = txtEmail.Text.Trim();
                h.Fax = txtFax.Text;

                if (HBMSValidations.Validate(h))
                {
                    HBMSValidations.AddHotel(h);
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Hotel Added Successfully')", true);
                    
                }
            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
                
            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
            }
        }
    }
}