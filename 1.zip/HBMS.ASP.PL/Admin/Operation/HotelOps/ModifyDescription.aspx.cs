﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Admin.Operation.HotelOps
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                txtID.Text = Session["Hid"].ToString();
            }

            catch(SystemException)
            { }
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                int records = 0;
                records = HBMSValidations.ModifyHotel(txtDescription.Text, txtID.Text);

                if (records > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Hotel Description Modified Successfully')", true);
                    
                }
                else
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Hotel description not modified')", true);
                    
            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
            }
        }
    }
}