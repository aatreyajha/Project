﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL
{
    public partial class Welcome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string loc = Session["loc"].ToString();
                grdHotellist.DataSource = HBMSValidations.SearchHotel(loc);
                grdHotellist.DataBind();
                lblLoc.Text = "Hotels in " + loc;

            }
            catch(SystemException)
            {
                DropDownList2.Visible = true;
                btnShow.Visible = true;
                DropDownList2.DataSource = HBMSValidations.GetHotelLocations();
                DropDownList2.DataBind();
            }
            finally
            {
                string role = Session["loginstatus"].ToString();
                if (role == "User")
                {
                    HBMSMaster myMasterPage = (HBMSMaster)Page.Master;

                    ControlCollection li = myMasterPage.Controls;

                    LinkButton re = (LinkButton)myMasterPage.FindControl("linkbtn_Register");
                    re.Enabled = false;
                    re.Visible = false;

                    LinkButton lo = (LinkButton)myMasterPage.FindControl("linkbtn_Login");
                    lo.Text = "Log Out";
                    lo.PostBackUrl = "~/Default.aspx";
                }

                imgRoom.Visible = false;
                btnBook.Visible = false;
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["loc"] = DropDownList2.SelectedValue;
        }

        protected void btnchngLoc_Click(object sender, EventArgs e)
        {
            DropDownList2.Visible = true;
            btnShow.Visible = true;
            DropDownList2.DataSource = HBMSValidations.GetHotelLocations();
            DropDownList2.DataBind();
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            string loc = DropDownList2.SelectedValue.ToString();
            grdHotellist.DataSource = HBMSValidations.SearchHotel(loc);
            grdHotellist.DataBind();
            DropDownList2.Visible = false;
            btnShow.Visible = false;
            lblLoc.Text = "Hotels in " + loc;
        }

       

        protected void btnBook_Click(object sender, EventArgs e)
        {
            string role = Session["loginstatus"].ToString();

            if (role=="Guest")
            {
                Response.Redirect("Account/Login.aspx");
            }
            else if(role=="User")
            {
                Response.Redirect("BookingPage.aspx");
            }
            else
            {
                //invalid user
            }
        }

        protected void LinkBtnName_Command(object sender, CommandEventArgs e)
        {
            string hid=e.CommandArgument.ToString(); 
            
            
            imgRoom.Visible = true;
            btnBook.Visible = true;
            Session["hotelid"] = hid;
        }

      
    }
}