﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HBMS.BL;
using HBMS.Entity;
using HBMS.Exception;
using System.Data.Entity.Validation;

namespace HBMS.ASP.PL
{
    public partial class BookingPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            try
            {
                if (Session["loginstatus"].ToString() != "User")
                {
                    Response.Redirect("/Account/Login.aspx");
                }

                hotelID = Session["hotelid"].ToString();
                userid = Session["userid"].ToString();
            }

            finally
            {
                HBMSMaster myMasterPage = (HBMSMaster)Page.Master;

                ControlCollection li = myMasterPage.Controls;

                LinkButton re = (LinkButton)myMasterPage.FindControl("linkbtn_Register");
                re.Enabled = false;
                re.Visible = false;

                LinkButton lo = (LinkButton)myMasterPage.FindControl("linkbtn_Login");
                lo.Text = "Log Out";
                lo.PostBackUrl = "~/Default.aspx";
            }
        }

        protected void btnBookFrom_Click(object sender, EventArgs e)
        {
            calBookFrom.Visible=true;
            calBookFrom.VisibleDate=DateTime.Today;
        }

        protected void calBookFrom_SelectionChanged(object sender, EventArgs e)
        {
            txtBookFrom.Text = calBookFrom.SelectedDate.ToShortDateString();
            calBookFrom.Visible = false;
        }

        protected void btnBookTo_Click(object sender, EventArgs e)
        {
            calBookTo.Visible = true;
            calBookTo.VisibleDate = DateTime.Today;
        }

        protected void calBookTo_SelectionChanged(object sender, EventArgs e)
        {
            txtBookTo.Text = calBookTo.SelectedDate.ToShortDateString();
            calBookTo.Visible = false;
        }

        protected void calBookFrom_DayRender(object sender, DayRenderEventArgs e)
        {
            if (e.Day.Date <= DateTime.Now)
            {
                e.Day.IsSelectable = false;
                e.Cell.Enabled = false;
            }
        }

        int roomid,sq = 0;
        string userid , hotelID ;
        protected void btnCheckRoom_Click(object sender, EventArgs e)
        {
            try
            {
                if (HBMSValidations.CheckAvailablility(hotelID))
                {
                    btnCheckRoom.Text = "Rooms are available";

                    btnCheckRoom.ForeColor = System.Drawing.Color.GreenYellow;
                    btnCheckRoom.BackColor = System.Drawing.Color.LightSlateGray;
                    btnCheckRoom.Font.Bold = true;


                    roomid = 1;
                    btnBookRoom.Enabled = true;
                }
            }
            catch (System.Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);
               
            }
        }

        protected void btnBookRoom_Click(object sender, EventArgs e)
        {
            try
            {
                BookingDetail bd = new BookingDetail();
                bd.BookedFrom = (DateTime)calBookFrom.SelectedDate;
                bd.BookedTo = (DateTime)calBookTo.SelectedDate;
                bd.NoOfAdults = Convert.ToInt32(txtNoOfAdult.Text);
                //
                int o;
                int.TryParse(txtNoOfChild.Text, out o);

                bd.NoOfChildren = o;
                bd.UserID = userid;
                bd.RoomID = 1;
                string ty = ddRoomType.SelectedItem.ToString();
                int records = HBMSValidations.BookRoom(bd, ty);

                if (records > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Room Booked successsfully')", true);
                }

                else
                    throw new HBMSException("Provide proper Details");

            }

          
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (SystemException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
        }

        
    }
}