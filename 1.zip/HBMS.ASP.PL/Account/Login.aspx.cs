﻿using System;
using System.Web;
using System.Web.UI;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register";
            var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            if (!String.IsNullOrEmpty(returnUrl))
            {
                RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            }
        }

        protected void LogIn(object sender, EventArgs e)
        {
            try
            {
                
                int records = HBMSValidations.CheckLogin(UserId.Text, Password.Text);

                if (records==1)
                {

                    Session["userid"] = UserId.Text;
                    Session["loginstatus"] = "User";
                    Response.Redirect(@"../Admin/Operation/HotelOps/ListHotel.aspx",false);
                }
                else if(records==-1)
	            {
                    Session["userid"] = UserId.Text;
                    Session["loginstatus"] = "User";
                    Response.Redirect(@"../Welcome.aspx",false);
	            }
                else
                {
                    throw new HBMSException("Provide proper Details");
                }
                    
            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (SystemException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
        }
    }
}