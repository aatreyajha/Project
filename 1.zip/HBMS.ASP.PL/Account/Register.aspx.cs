﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Drawing;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.ASP.PL.Account
{
    public partial class Register : Page
    {
        protected void CreateUser_Click(object sender, EventArgs e)
        {
            try
            {
                User u = new User();
                u.UserName = UserName.Text;
                u.Mobile = Mobile.Text;
                u.Password = Password.Text;
                u.Email = Email.Text;
                u.Address = Address.Text;
                u.Role = Role.SelectedValue;

                string userID = HBMSValidations.RegisterUserReturningId(u);


                if (userID!=null)
                {
                    UserId.Text = userID;
                    UserId.BorderColor = Color.Red;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('Registration Successful! Please check your UserId displayed in the textbox and Login to continue')", true);
                }

                else
                {
                    throw new HBMSException("Provide proper Details");
                }

            }
            catch (HBMSException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
            catch (SystemException ex)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('" + ex.Message + "')", true);

            }
        }
    }
}