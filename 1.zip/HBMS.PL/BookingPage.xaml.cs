﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for BookingPage.xaml
    /// </summary>
    public partial class BookingPage : Window
    {
        public BookingPage()
        {
            InitializeComponent();

            //Initializing Room type Combobox
            cmbRoomType.DataContext=new string[]{"Standard Non A/C","Standard A/C","Executive A/C","Deluxe A/C"};
            cmbRoomType.SelectedIndex = 0;

            //Restict datepicker to  current date 
            dpBookFrom.DisplayDateStart=DateTime.Today;
            dpBookTo.DisplayDateStart = DateTime.Today;
        }


        string userid,hotelID;
        public BookingPage(string id,string hid="1002")
        {
            InitializeComponent();

            //Initializing Room type Combobox
            cmbRoomType.DataContext = new string[] { "Standard Non A/C", "Standard A/C", "Executive A/C", "Deluxe A/C" };
            cmbRoomType.SelectedIndex = 0;

            //Restict datepicker to  current date 
            dpBookFrom.DisplayDateStart = DateTime.Today;
            dpBookTo.DisplayDateStart = DateTime.Today;

            userid = id;
            hotelID = hid;
        }

        private void cmbRoomType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //selection changed events
        }


        //Check room availability
       int roomid;
        private void btnRoomAvailability_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (HBMSValidations.CheckAvailablility(hotelID))
                {
                    btnRoomAvailability.Content = "Rooms are available";

                    btnRoomAvailability.Foreground = Brushes.GreenYellow;
                    btnRoomAvailability.Background = Brushes.LightSlateGray;
                    btnRoomAvailability.FontWeight = FontWeights.Bold;

                    
                    roomid = 1;

                    btnBookRoom.IsEnabled = true;
                }
            }
            catch (System.Exception)
            {

                throw;
            }
        }


        private void btnBookRoom_Click(object sender, RoutedEventArgs e)
        {
            //book room events
            try 
            {
                BookingDetail bd = new BookingDetail();
                bd.BookedFrom = (DateTime)dpBookFrom.SelectedDate;
                bd.BookedTo = (DateTime)dpBookTo.SelectedDate;
                bd.NoOfAdults = Convert.ToInt32(txtNumAdult.Text);
                //
                int o;
                int.TryParse(txtNumChildren.Text,out o);

                bd.NoOfChildren = o;
                bd.UserID = userid;
                bd.RoomID = roomid;
                string ty = cmbRoomType.SelectedItem.ToString();
                int records = HBMSValidations.BookRoom(bd,ty);

                if (records > 0)
                {
                    MessageBox.Show("Room Book successsfully");
                }

                else
                    throw new HBMSException("Provide proper Details");
                         


            }

            catch(HBMSException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSignOut_Click(object sender, RoutedEventArgs e)
        {
            //redirect it to Login Page
            Login l = new Login();
            l.Show();
            Close();
        }
    }
}
