﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;

namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {
       List<Hotel> hlist = new List<Hotel>();
        List<string> h =null;
        List<string> hid = null;

        public AdminPanel()
        {
            InitializeComponent();
            hlist = HBMSValidations.GetHotelList();
            h = new List<string>();
            hid = new List<string>();



            foreach (var item in hlist)
            {
                h.Add(item.HotelName);
                hid.Add(item.HotelID);
            }

            cmbHotelList.DataContext = h;



            cmbRoomType.DataContext = new string[] { "Standard Non A/C", "Standard A/C", "Executive A/C", "Deluxe A/C" };
            cmbRoomType.SelectedIndex = 0;

            dpBookings.SelectedDate = DateTime.Today;
        }


        //Add Room
        private void btnARAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RoomDetail objRoom = new RoomDetail();
                objRoom.HotelID = hid[h.FindIndex(s => s == cmbHotelList.SelectedValue.ToString())];
                objRoom.RoomNo = txtARoomNumber.Text;
                objRoom.RoomType = cmbRoomType.SelectedValue.ToString();
                objRoom.PerNightRate = Convert.ToInt32(txtARoomFare.Text);
                objRoom.Availability = true;
                int r = HBMSValidations.AddRoom(objRoom);

                if (r > 0)
                {
                    MessageBox.Show("Room added successfully");
                }

                else
                    throw new HBMSException("Room not added");
            }
            catch (HBMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //Delete room
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int delRoomId = Convert.ToInt32(txtDRoomID.Content);
            string delHotelId = txtDHotelID.Content.ToString();
            try
            {
                int r = HBMSValidations.DeleteRoom(delHotelId, delRoomId);

                if (r > 0)
                {
                    MessageBox.Show("Room deleted successfully");

                    dgRoomOps.DataContext = HBMSValidations.GetRoomList();
                    dgRoomOps.Items.Refresh();
                }

                else
                    throw new HBMSException("Room not deleted");
            }
            catch (HBMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        //Modify Room
        private void btnModify_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                RoomDetail rd = new RoomDetail();
                rd.RoomID = Convert.ToInt32(txtMRRoomID.Content);
                rd.HotelID = txtMRHotelID.Content.ToString();
                rd.PerNightRate = Convert.ToInt32(txtMRFare.Text);

                int r = HBMSValidations.ModifyRoom(rd);

                if (r > 0)
                {
                    MessageBox.Show("Room Fare Modified successfully");
                    dgRoomOps.DataContext = HBMSValidations.GetRoomList();
                }

                else
                    throw new HBMSException("Room not modified");
            }
            catch (HBMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        //Getting Room List
        private void btnRoomList_Click(object sender, RoutedEventArgs e)
        {
            dgRoomOps.DataContext = HBMSValidations.GetRoomList();

        }


        //RoomDataGrid Selection Changed
        private void dgRoomOps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                RoomDetail rd = (RoomDetail)dgRoomOps.SelectedItem;
                txtMRRoomID.Content = rd.RoomID;
                txtMRHotelID.Content = rd.HotelID;
                txtDHotelID.Content = rd.HotelID;
                txtDRoomID.Content = rd.RoomID;
            }
            catch (SystemException)
            {

            }
        }


        private void btnSearchHotelBooking_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string s = txtSearchHotelBooking.Text;
                dgReports.DataContext = HBMSValidations.GetBookingDetails("1");
                dgReports.Items.Refresh();
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }

        //Reports List hotel Button
        private void btnListHotel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dgReports.DataContext = HBMSValidations.GetHotelList();

                dgReports.Items.Refresh();
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }

        //report search guest
        private void btnSearchHotelGuest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<User> liq = HBMSValidations.GetGuests(txtSearchHotelGuest.Text);
                if (liq != null)
                {
                    dgReports.DataContext = liq;
                    dgReports.Items.Refresh();
                }
                else
                {
                    MessageBox.Show("No guest found in hotel...");
                }
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }

        }

        private void dpBookings_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var date = Convert.ToDateTime(dpBookings.Text);
                List<BookingDetail> liq = HBMSValidations.GetBookingsForADate(date);
                if (liq != null)
                {
                    dgReports.DataContext = liq;
                    dgReports.Items.Refresh();
                }
                else
                {
                    MessageBox.Show("No booking details found on " + dpBookings.Text);
                }
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }

        }

        //Operations Add new hotel
        private void btnAH_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Hotel h = new Hotel();
                h.HotelID = txtAHotelID.Text.Trim();
                h.HotelName = txtAHname.Text.Trim();
                h.City = txtAHCity.Text.Trim();
                h.Address = txtAHAddress.Text.Trim();
                h.Description = txtAHDescription.Text.Trim();
                h.PhoneNo1 = txtAHMobile.Text;
                h.PhoneNo2 = txtAHPhone.Text;
                h.Rating = txtAHRating.Text;
                h.Email = txtAHEmail.Text.Trim();
                h.Fax = txtAHFax.Text;

                if (HBMSValidations.Validate(h))
                {
                    HBMSValidations.AddHotel(h);
                    MessageBox.Show("Hotel Added successfully");
                    dgHotelOps.DataContext = HBMSValidations.GetHotelList();
                    dgHotelOps.Items.Refresh();
                }
            }
            catch (HBMSException )
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }   
            catch (System.Exception )
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }


        //Delete Hotel
        private void btnDHDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int count = HBMSValidations.DeleteHotel(lblDHHotelID.Content.ToString());

                if (count>0)
                {
                    MessageBox.Show("Hotel deleted successfully");
                    dgHotelOps.DataContext = HBMSValidations.GetHotelList();
                    dgHotelOps.Items.Refresh();
                }
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }

        //Modify description of hotel
        private void btnMHModify_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int records = 0;
                records = HBMSValidations.ModifyHotel(txtMHDescription.Text, ((Hotel)dgHotelOps.SelectedItem).HotelID);

                if (records > 0)
                {
                    MessageBox.Show("Hotel Description Modified Successfully");
                    dgHotelOps.DataContext = HBMSValidations.GetHotelList();

                    dgHotelOps.Items.Refresh();
                }

                else
                    MessageBox.Show("Hotel Description not modified");
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }
       

        //operation hotel bind values of label in delete & modify 
        private void dgHotelOps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                Hotel hotel = (Hotel)dgHotelOps.SelectedItem;
                lblDHHotelID.Content = hotel.HotelID;
                lblMHHotelID.Content = hotel.HotelID;
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }

        //list hotel 
        private void btnOListHotel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dgHotelOps.DataContext = HBMSValidations.GetHotelList();

                dgHotelOps.Items.Refresh();
            }
            catch (HBMSException)
            {
                MessageBox.Show("Unexpected error happened\nUnable to add hotel");
                throw;
            }
            catch (System.Exception)
            {
                MessageBox.Show("Unexpected system error happened\nUnable to add hotel");
            }
        }

        
    }
}
