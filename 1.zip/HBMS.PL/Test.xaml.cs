﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;
using System.Data.Entity.Validation;
using HBMS.Entity;

namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for Test.xaml
    /// </summary>
    public partial class Test : Window
    {


        public Test()
        {
            InitializeComponent();

            HotelEntities context = new HotelEntities();
            DataContext =(from s in  context.RoomDetails
                              select s).ToList<RoomDetail>();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            User ob = new User();
            //ob.ID = 45;
            //ob.UserID = "qwer";
            ob.Role = "Guest";
            ob.UserName = "Marvin";
            ob.Password = "Qwert";
            ob.Mobile = "7896541230";
            //ob.Address = "Vegas";
            ob.Email = "acd12@gmail.com";

            try
            {
                using (HotelEntities context = new HotelEntities())
                {
                    context.Users.Add(ob);
                    context.SaveChanges();

                    DataContext = context.Users.ToList();
                    dgUser.Items.Refresh();
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (DbEntityValidationResult entityErr in dbEx.EntityValidationErrors)
                {
                    foreach (DbValidationError error in entityErr.ValidationErrors)
                    {
                        MessageBox.Show(error.PropertyName + "\n" + error.ErrorMessage);
                    }
                }
            }



        }
    }
}
