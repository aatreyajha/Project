﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;


namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

         Registration registration = new Registration();
         
 
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (txtUserId.Text.Length == 0)
            {
                errormessage.Text = "Enter UserId.";
                txtUserId.Focus();
            }

            else if (txtPassword.Password.Length == 0)
            {
                errormessage.Text = "Enter Password.";
                txtPassword.Focus();
            }
            
            else
            {
                string userid = txtUserId.Text;
                string password = txtPassword.Password;
                    
                /*Code to retrieve data matching userid and password*/
                int status=HBMSValidations.CheckLogin(userid,password);

               
                if (status==-1)
                {
                    Welcome welcome = new Welcome(txtUserId.Text);
                    welcome.Show();
                    Close();
                }

                else if(status==1)
                {
                    AdminPanel ad = new AdminPanel();
                    ad.Show();
                    Close();
                }

                else
                {
                    errormessage.Text = "Sorry! Please enter valid UserID or password.";
                }
               
            }
        }
 
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            registration.Show();
            Close();
        }
 
    }
}



