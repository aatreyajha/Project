﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HBMS.BL;
using HBMS.Entity;
using HBMS.Exception;

namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for Welcome.xaml
    /// </summary>
    public partial class Welcome : Window
    {
        public Welcome()
        {
            InitializeComponent();
            cmbLocation.DataContext = HBMSValidations.GetHotelLocations();
        }


        string userid,hotelid;
        public Welcome(string id)
        {
            InitializeComponent();
            cmbLocation.DataContext = HBMSValidations.GetHotelLocations();
            userid = id;
            
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            if (cmbLocation.SelectedIndex < 0)
            {
                MessageBox.Show("Please select location...");
            }

            //MessageBox.Show( cmbLocation.SelectedItem.ToString());
            else
            {
                string loc = cmbLocation.SelectedValue.ToString();

                dgLocation.DataContext = HBMSValidations.SearchHotel(loc);
            }
        }

        private void btnSelectHotel_Click(object sender, RoutedEventArgs e)
        {
            hotelid = "1002";
            BookingPage bk = new BookingPage(userid,hotelid);
            bk.Show();
            Close();
        }

         
      
    }

    
}
