﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HBMS.Entity;
using HBMS.Exception;
using HBMS.BL;
using System.Data.Entity.Validation;


namespace HBMS.PL
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Login login = new Login();
            login.Show();
            Close();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        public void Reset()
        {
            textBoxUserName.Text = "";
            
            cmbBoxRole.SelectedIndex = -1;
            textBoxMobileNo.Text = "";
            textBoxPhone.Text = "";
            textBoxEmail.Text = "";
            textBoxAddress.Text = "";
            passwordBox1.Password = "";
            passwordBoxConfirm.Password = "";
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
                
               if (passwordBoxConfirm.Password.Length == 0)
                {
                    errormessage.Text = "Enter Confirm password.";
                    passwordBoxConfirm.Focus();
                }
                else if (passwordBox1.Password != passwordBoxConfirm.Password)
                {
                    errormessage.Text = "Confirm password must be same as password.";
                    passwordBoxConfirm.Focus();
                }
                else
                {
                    try
                    {
                        User u = new User();
                        u.UserName = textBoxUserName.Text;
                        u.Mobile = textBoxMobileNo.Text;
                        u.Password =passwordBox1.Password;
                        u.Email = textBoxEmail.Text;
                        u.Address=textBoxAddress.Text;
                        u.Role=((ComboBoxItem)(cmbBoxRole.SelectedItem)).Content.ToString();

                        int records = HBMSValidations.RegisterUser(u);

                        if (records > 0)
                        {
                            MessageBox.Show("You have Registered successfully.");
                            Reset();

                            
                        }
                        else
                            throw new HBMSException("User Registration failed!");
                        
                    }
                    catch(HBMSException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    catch(SystemException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }
    }


